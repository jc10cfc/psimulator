/* net/if.h

   Copyright 1998, 2001 Red Hat, Inc.

This file is part of Cygwin.

This software is a copyrighted work licensed under the terms of the
Cygwin license.  Please consult the file "CYGWIN_LICENSE" for
details. */

#ifndef _NET_IF_H
#define _NET_IF_H

#include <cygwin/if.h>

#endif /* _NET_IF_H */
