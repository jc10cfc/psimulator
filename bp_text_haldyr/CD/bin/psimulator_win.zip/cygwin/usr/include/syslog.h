/* syslog.h

   Copyright 1996, 1998, 2001 Red Hat, Inc.

This file is part of Cygwin.

This software is a copyrighted work licensed under the terms of the
Cygwin license.  Please consult the file "CYGWIN_LICENSE" for
details. */

#ifndef _SYSLOG_H
#define _SYSLOG_H

#include <sys/syslog.h>

#endif /* _SYSLOG_H */
