/* wordsize.h - Linux compatibility */

#ifndef _WORDSIZE_H
#define _WORDSIZE_H 1
#define __WORDSIZE      32
#endif /*_WORDSIZE_H*/
